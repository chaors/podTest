//
//  ABUMintegralPersonaliseCfgAdapter.h
//  ABUDemo
//
//  Created by wangchao on 2020/4/16.
//  Copyright © 2020 wangchao. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUMintegralPersonaliseConfigAdapter : NSObject

@end

NS_ASSUME_NONNULL_END
