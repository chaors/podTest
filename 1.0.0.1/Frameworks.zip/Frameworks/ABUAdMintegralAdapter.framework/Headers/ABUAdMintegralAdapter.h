//
//  ABUAdMintegralAdapter.h
//  ABUAdMintegralAdapter
//
//  Created by wangchao on 2020/3/16.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ABUAdMintegralAdapter.
FOUNDATION_EXPORT double ABUAdMintegralAdapterVersionNumber;

//! Project version string for ABUAdMintegralAdapter.
FOUNDATION_EXPORT const unsigned char ABUAdMintegralAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ABUAdMintegralAdapter/PublicHeader.h>


