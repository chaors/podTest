//
//  ABUAdAdmobAdapter.h
//  ABUAdAdmobAdapter
//
//  Created by wangchao on 2020/3/12.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ABUAdAdmobAdapter.
FOUNDATION_EXPORT double ABUAdAdmobAdapterVersionNumber;

//! Project version string for ABUAdAdmobAdapter.
FOUNDATION_EXPORT const unsigned char ABUAdAdmobAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ABUAdAdmobAdapter/PublicHeader.h>


