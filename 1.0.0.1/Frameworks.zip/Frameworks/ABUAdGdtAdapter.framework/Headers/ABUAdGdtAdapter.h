//
//  ABUAdGdtAdapter.h
//  ABUAdGdtAdapter
//
//  Created by wangchao on 2020/3/9.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ABUAdGdtAdapter.
FOUNDATION_EXPORT double ABUAdGdtAdapterVersionNumber;

//! Project version string for ABUAdGdtAdapter.
FOUNDATION_EXPORT const unsigned char ABUAdGdtAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ABUAdGdtAdapter/PublicHeader.h>


